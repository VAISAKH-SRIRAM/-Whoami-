// Projects data
export const projects = [
  {
    id: 1,
    title: "Neural Chat Interface",
    description: "An AI-powered chat application with real-time response generation and code syntax highlighting.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=400",
    category: "Web Application",
    technologies: ["React", "Node.js", "TensorFlow"],
    link: "#"
  },
  {
    id: 2,
    title: "Data Terrain Explorer",
    description: "A 3D data visualization tool that transforms complex datasets into explorable terrain landscapes.",
    image: "https://images.unsplash.com/photo-1550439062-609e1531270e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=400",
    category: "3D Visualization",
    technologies: ["Three.js", "D3.js", "WebGL"],
    link: "#"
  },
  {
    id: 3,
    title: "CodeSync Platform",
    description: "A collaborative coding platform with real-time syncing, video chat, and integrated deployment.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=400",
    category: "Full-Stack",
    technologies: ["Vue.js", "Firebase", "WebRTC"],
    link: "#"
  }
];

// Blog posts data
export const blogPosts = [
  {
    id: 1,
    title: "Creating Immersive Web Experiences with WebGL Shaders",
    excerpt: "A deep dive into how custom WebGL shaders can transform boring websites into interactive experiences.",
    date: "June 12, 2023",
    category: "WebGL",
    aiSummary: "Pixels dance and sing, \nCode transforms the mundane web, \nArt meets technology.",
    link: "#"
  },
  {
    id: 2,
    title: "Scalable Frontend Architecture for Enterprise Applications",
    excerpt: "How to structure large-scale frontend projects to maintain performance and developer sanity.",
    date: "May 28, 2023",
    category: "Architecture",
    aiSummary: "Strong foundations laid, \nCode flows in organized streams, \nGrowth without chaos.",
    link: "#"
  },
  {
    id: 3,
    title: "Leveraging AI in the UX Design Process",
    excerpt: "Exploring how artificial intelligence can enhance and accelerate the user experience design workflow.",
    date: "April 15, 2023",
    category: "AI & Design",
    aiSummary: "Silicon intuition, \nHuman creativity enhanced, \nNew paths discovered.",
    link: "#"
  }
];

// Tech stack
export const techStack = [
  "React", "Node.js", "Three.js", "WebGL", "TypeScript", "Python", "AWS"
];

// Skills categories
export const skillCategories = [
  {
    name: "Frontend",
    skills: [
      "React & React Native",
      "Vue.js",
      "TypeScript",
      "Tailwind CSS",
      "Three.js & WebGL"
    ]
  },
  {
    name: "Backend",
    skills: [
      "Node.js & Express",
      "Python & Django",
      "GraphQL & REST APIs",
      "MongoDB & PostgreSQL",
      "Firebase & Supabase"
    ]
  },
  {
    name: "DevOps & Cloud",
    skills: [
      "AWS Services",
      "Docker & Kubernetes",
      "CI/CD Pipelines",
      "Terraform & IaC",
      "Monitoring & Logging"
    ]
  },
  {
    name: "Creative & Data",
    skills: [
      "WebGL Shaders",
      "Data Visualization",
      "Machine Learning",
      "UI/UX Design",
      "Creative Coding"
    ]
  }
];
