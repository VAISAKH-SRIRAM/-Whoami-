import { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface SkillsVisualizationProps {
  className?: string;
}

const SkillsVisualization = ({ className }: SkillsVisualizationProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Create scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75, 
      containerRef.current.clientWidth / containerRef.current.clientHeight, 
      0.1, 
      1000
    );
    camera.position.z = 15;

    // Create renderer with transparency
    const renderer = new THREE.WebGLRenderer({ 
      alpha: true,
      antialias: true 
    });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    containerRef.current.appendChild(renderer.domElement);

    // Create a group for nodes and connections
    const nodesGroup = new THREE.Group();
    scene.add(nodesGroup);

    // Define skill categories
    const categories = [
      { name: 'Frontend', skills: ['React', 'Vue', 'TypeScript', 'WebGL', 'Three.js'] },
      { name: 'Backend', skills: ['Node.js', 'Python', 'GraphQL', 'MongoDB', 'PostgreSQL'] },
      { name: 'DevOps', skills: ['AWS', 'Docker', 'CI/CD', 'Kubernetes', 'Terraform'] },
      { name: 'Creative', skills: ['Shaders', 'UI/UX', 'Data Viz', 'Animation', 'Creative Coding'] }
    ];
    
    const nodes: THREE.Mesh[] = [];
    const nodePositions: THREE.Vector3[] = [];
    const connections: THREE.Line[] = [];
    
    // Create a teal glow material for nodes
    const nodeGeometry = new THREE.SphereGeometry(0.3, 16, 16);
    const nodeMaterial = new THREE.MeshPhongMaterial({ 
      color: 0x009c79,
      emissive: 0x009c79,
      emissiveIntensity: 0.5,
      shininess: 100
    });
    
    // Create node for each skill
    let nodeIndex = 0;
    categories.forEach((category, categoryIndex) => {
      const categoryAngle = (categoryIndex / categories.length) * Math.PI * 2;
      const categoryRadius = 8;
      const categoryPosition = new THREE.Vector3(
        Math.cos(categoryAngle) * categoryRadius,
        Math.sin(categoryAngle) * categoryRadius,
        0
      );
      
      // Create category center node
      const centerNode = new THREE.Mesh(nodeGeometry, nodeMaterial);
      centerNode.position.copy(categoryPosition);
      centerNode.scale.set(1.5, 1.5, 1.5);
      nodesGroup.add(centerNode);
      nodes.push(centerNode);
      nodePositions.push(categoryPosition.clone());
      
      // Create skill nodes around category
      category.skills.forEach((skill, skillIndex) => {
        const skillAngle = (skillIndex / category.skills.length) * Math.PI * 2 + categoryAngle;
        const skillRadius = 3;
        const skillPosition = new THREE.Vector3(
          categoryPosition.x + Math.cos(skillAngle) * skillRadius,
          categoryPosition.y + Math.sin(skillAngle) * skillRadius,
          (Math.random() - 0.5) * 2 // Add some z-variation
        );
        
        const node = new THREE.Mesh(nodeGeometry, nodeMaterial);
        node.position.copy(skillPosition);
        nodesGroup.add(node);
        nodes.push(node);
        nodePositions.push(skillPosition.clone());
        
        // Connect skill node to category node
        const connectionGeometry = new THREE.BufferGeometry().setFromPoints([
          categoryPosition,
          skillPosition
        ]);
        const connectionMaterial = new THREE.LineBasicMaterial({ 
          color: 0x009c79,
          opacity: 0.3,
          transparent: true
        });
        const connection = new THREE.Line(connectionGeometry, connectionMaterial);
        nodesGroup.add(connection);
        connections.push(connection);
        
        nodeIndex++;
      });
    });
    
    // Create random connections between some nodes to make it more interconnected
    for (let i = 0; i < 10; i++) {
      const randomNodeA = Math.floor(Math.random() * nodes.length);
      const randomNodeB = Math.floor(Math.random() * nodes.length);
      
      if (randomNodeA !== randomNodeB) {
        const connectionGeometry = new THREE.BufferGeometry().setFromPoints([
          nodePositions[randomNodeA],
          nodePositions[randomNodeB]
        ]);
        const connectionMaterial = new THREE.LineBasicMaterial({ 
          color: 0x009c79,
          opacity: 0.1,
          transparent: true
        });
        const connection = new THREE.Line(connectionGeometry, connectionMaterial);
        nodesGroup.add(connection);
        connections.push(connection);
      }
    }

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    // Add point light
    const pointLight = new THREE.PointLight(0x00c79a, 1, 100);
    pointLight.position.set(0, 0, 10);
    scene.add(pointLight);
    
    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      
      // Rotate the entire nodes group
      nodesGroup.rotation.x += 0.002;
      nodesGroup.rotation.y += 0.003;
      
      renderer.render(scene, camera);
    };

    animate();

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current) return;
      
      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && containerRef.current.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
      
      nodeGeometry.dispose();
      nodeMaterial.dispose();
      
      connections.forEach(connection => {
        connection.geometry.dispose();
        (connection.material as THREE.Material).dispose();
      });
    };
  }, []);

  return <div ref={containerRef} className={className || "w-full h-96"} />;
};

export default SkillsVisualization;
