import { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface AvatarProps {
  className?: string;
}

const Avatar = ({ className }: AvatarProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Set up scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    camera.position.z = 2.5;

    // Create renderer with transparency
    const renderer = new THREE.WebGLRenderer({ 
      alpha: true,
      antialias: true
    });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    containerRef.current.appendChild(renderer.domElement);

    // Create a simple avatar (sphere with special material)
    const geometry = new THREE.SphereGeometry(1, 32, 32);
    
    // Create a teal and navy shader material
    const material = new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 }
      },
      vertexShader: `
        varying vec2 vUv;
        varying vec3 vNormal;
        
        void main() {
          vUv = uv;
          vNormal = normal;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float time;
        varying vec2 vUv;
        varying vec3 vNormal;
        
        void main() {
          // Navy and teal colors
          vec3 navy = vec3(0.086, 0.122, 0.149);
          vec3 teal = vec3(0.0, 0.612, 0.475);
          
          // Create pattern based on normal and time
          float pattern = sin(vNormal.x * 10.0 + time) * sin(vNormal.y * 10.0 + time) * sin(vNormal.z * 10.0 + time);
          pattern = smoothstep(-0.2, 0.2, pattern);
          
          // Mix colors based on pattern
          vec3 finalColor = mix(navy, teal, pattern);
          
          // Add rim lighting effect
          float rimLight = 1.0 - max(dot(vNormal, vec3(0.0, 0.0, 1.0)), 0.0);
          rimLight = pow(rimLight, 2.0);
          finalColor += teal * rimLight * 0.5;
          
          gl_FragColor = vec4(finalColor, 1.0);
        }
      `
    });

    const avatar = new THREE.Mesh(geometry, material);
    scene.add(avatar);

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0x00c79a, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      
      // Rotate the avatar slowly
      avatar.rotation.y += 0.005;
      avatar.rotation.x += 0.002;
      
      // Update shader time uniform
      (material as THREE.ShaderMaterial).uniforms.time.value += 0.01;
      
      renderer.render(scene, camera);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      if (!containerRef.current) return;
      
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && containerRef.current.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
      geometry.dispose();
      material.dispose();
    };
  }, []);

  return <div ref={containerRef} className={className} />;
};

export default Avatar;
