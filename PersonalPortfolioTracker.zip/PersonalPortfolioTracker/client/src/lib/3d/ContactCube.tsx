import { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface ContactCubeProps {
  className?: string;
}

const ContactCube = ({ className }: ContactCubeProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Set up scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75, 
      containerRef.current.clientWidth / containerRef.current.clientHeight, 
      0.1, 
      1000
    );
    camera.position.z = 4;

    // Create renderer with transparency
    const renderer = new THREE.WebGLRenderer({ 
      alpha: true,
      antialias: true 
    });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    containerRef.current.appendChild(renderer.domElement);

    // Create cube with wireframe
    const cubeGeometry = new THREE.BoxGeometry(2, 2, 2);
    
    // Create edge geometry for the glowing edges
    const edges = new THREE.EdgesGeometry(cubeGeometry);
    const edgeMaterial = new THREE.LineBasicMaterial({ 
      color: 0x009c79,
      linewidth: 2
    });
    const wireframe = new THREE.LineSegments(edges, edgeMaterial);
    
    // Create a subtle face material
    const faceMaterial = new THREE.MeshPhongMaterial({
      color: 0x161f26,
      opacity: 0.7,
      transparent: true,
      side: THREE.DoubleSide,
      shininess: 100,
      specular: 0x009c79
    });
    
    // Create cube with faces
    const cube = new THREE.Mesh(cubeGeometry, faceMaterial);
    
    // Add both to a group
    const cubeGroup = new THREE.Group();
    cubeGroup.add(cube);
    cubeGroup.add(wireframe);
    
    scene.add(cubeGroup);

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
    scene.add(ambientLight);

    // Add point light
    const pointLight = new THREE.PointLight(0x00c79a, 1, 100);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);
    
    // Add another point light from different angle
    const pointLight2 = new THREE.PointLight(0x00c79a, 0.5, 100);
    pointLight2.position.set(-5, -5, 5);
    scene.add(pointLight2);

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      
      // Rotate the cube slowly
      cubeGroup.rotation.x += 0.005;
      cubeGroup.rotation.y += 0.007;
      
      renderer.render(scene, camera);
    };

    animate();

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current) return;
      
      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && containerRef.current.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
      
      cubeGeometry.dispose();
      edges.dispose();
      edgeMaterial.dispose();
      faceMaterial.dispose();
    };
  }, []);

  return <div ref={containerRef} className={className || "w-full h-64"} />;
};

export default ContactCube;
