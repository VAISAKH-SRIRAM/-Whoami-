import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function createGlitchAnimation(text: string, color1: string, color2: string) {
  // Return a string template for the glitch animation
  return `
    <span class="relative inline-block animate-glitch">
      <span class="${color1}">${text}</span>
    </span>
  `;
}
