import { Toaster } from "@/components/ui/toaster";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Projects from "./components/Projects";
import Skills from "./components/Skills";
import Collaborate from "./components/Collaborate";
import Blog from "./components/Blog";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

function App() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <Hero />
      <About />
      <Projects />
      <Skills />
      <Collaborate />
      <Blog />
      <Contact />
      <Footer />
      <Toaster />
    </div>
  );
}

export default App;
