import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { blogPosts } from '@/lib/constants';

const Blog = () => {
  return (
    <section id="blog" className="py-24 px-4 bg-background/80 relative">
      <div className="container mx-auto">
        <motion.h2 
          className="text-3xl md:text-4xl font-space font-bold mb-4 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
        >
          <span className="text-gradient">Blog </span>
          <span className="text-foreground">Articles</span>
        </motion.h2>
        
        <motion.p 
          className="text-center text-foreground/80 max-w-2xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          Insights, tutorials, and thoughts on development, design, and technology.
        </motion.p>
        
        {/* Blog Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {blogPosts.map((post, index) => (
            <motion.article 
              key={post.id}
              className="bg-background rounded-lg overflow-hidden border border-primary/30 hover:border-primary/60 transition-all duration-300"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
            >
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">{post.category}</span>
                  <span className="text-foreground/60 text-sm ml-auto">{post.date}</span>
                </div>
                <h3 className="text-xl font-space font-medium text-foreground mb-3 group-hover:text-accent transition-colors">
                  {post.title}
                </h3>
                <p className="text-foreground/70 text-sm mb-4">
                  {post.excerpt}
                </p>
                {/* AI Summary */}
                <div className="bg-primary/5 border border-primary/20 rounded p-3 mb-4">
                  <div className="text-xs text-primary mb-1">AI Summary</div>
                  <p className="text-foreground/90 text-xs italic whitespace-pre-line">
                    {post.aiSummary}
                  </p>
                </div>
                <a href={post.link} className="inline-block text-primary hover:text-accent transition-colors text-sm">
                  Read Article <span className="ml-1">→</span>
                </a>
              </div>
            </motion.article>
          ))}
        </div>
        
        {/* View All Articles Button */}
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Button asChild variant="outline" size="lg">
            <a href="#">Browse All Articles</a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Blog;
