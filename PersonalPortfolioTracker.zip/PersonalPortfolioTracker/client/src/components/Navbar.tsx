import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav className={cn(
      "fixed top-0 w-full z-50 transition-all duration-300 border-b border-primary/30",
      scrolled ? "bg-background/80 backdrop-blur-lg" : "bg-transparent"
    )}>
      <div className="container mx-auto px-4 md:px-6 py-4 flex justify-between items-center">
        <a href="#" className="text-xl font-space font-bold text-primary">
          VS<span className="text-foreground">.</span>
        </a>
        
        {/* Mobile Menu Button */}
        <div className="block lg:hidden">
          <button 
            onClick={toggleMobileMenu}
            className="text-foreground hover:text-primary focus:outline-none transition-colors"
            aria-label="Toggle menu"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
        
        {/* Desktop Menu */}
        <div className="hidden lg:flex space-x-8 items-center">
          <a href="#about" className="text-foreground hover:text-primary transition-colors">
            About
          </a>
          <a href="#projects" className="text-foreground hover:text-primary transition-colors">
            Projects
          </a>
          <a href="#skills" className="text-foreground hover:text-primary transition-colors">
            Skills
          </a>
          <a href="#collaborate" className="text-foreground hover:text-primary transition-colors">
            Collaborate
          </a>
          <a href="#blog" className="text-foreground hover:text-primary transition-colors">
            Blog
          </a>
          <Button asChild size="lg">
            <a href="#contact">Contact</a>
          </Button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div className={cn(
        "lg:hidden bg-background/95 backdrop-blur-lg border-t border-primary/30 pb-4",
        mobileMenuOpen ? "block" : "hidden"
      )}>
        <div className="container mx-auto px-4 space-y-3 pt-3">
          <a 
            href="#about" 
            className="block py-2 text-foreground hover:text-primary transition-colors"
            onClick={() => setMobileMenuOpen(false)}
          >
            About
          </a>
          <a 
            href="#projects" 
            className="block py-2 text-foreground hover:text-primary transition-colors"
            onClick={() => setMobileMenuOpen(false)}
          >
            Projects
          </a>
          <a 
            href="#skills" 
            className="block py-2 text-foreground hover:text-primary transition-colors"
            onClick={() => setMobileMenuOpen(false)}
          >
            Skills
          </a>
          <a 
            href="#collaborate" 
            className="block py-2 text-foreground hover:text-primary transition-colors"
            onClick={() => setMobileMenuOpen(false)}
          >
            Collaborate
          </a>
          <a 
            href="#blog" 
            className="block py-2 text-foreground hover:text-primary transition-colors"
            onClick={() => setMobileMenuOpen(false)}
          >
            Blog
          </a>
          <a 
            href="#contact" 
            className="block py-2 text-primary font-medium"
            onClick={() => setMobileMenuOpen(false)}
          >
            Contact
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
