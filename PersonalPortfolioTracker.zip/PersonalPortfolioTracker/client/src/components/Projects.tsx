import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { projects } from '@/lib/constants';

const Projects = () => {
  return (
    <section id="projects" className="py-24 px-4 bg-background/90 relative">
      <div className="container mx-auto">
        <motion.h2 
          className="text-3xl md:text-4xl font-space font-bold mb-4 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
        >
          <span className="text-foreground">Project </span>
          <span className="text-gradient">Showcase</span>
        </motion.h2>
        
        <motion.p 
          className="text-center text-foreground/80 max-w-2xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          A selection of my recent work spanning from interactive web apps to backend systems and creative coding projects.
        </motion.p>
        
        {/* Quantum Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {projects.map((project, index) => (
            <motion.div 
              key={project.id}
              className="teal-border bg-background rounded-lg overflow-hidden group transition-all duration-300"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={`${project.title} preview`} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent opacity-80"></div>
                <div className="absolute bottom-0 left-0 w-full p-4">
                  <span className="inline-block px-2 py-1 bg-primary/20 border border-primary/40 rounded text-xs text-primary mb-2">
                    {project.category}
                  </span>
                  <h3 className="text-xl font-space font-medium text-white group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                </div>
              </div>
              <div className="p-6">
                <p className="text-foreground/80 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, techIndex) => (
                    <span 
                      key={techIndex} 
                      className="px-2 py-1 bg-background/80 border border-primary/30 rounded-full text-xs text-accent"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <a 
                  href={project.link} 
                  className="inline-block text-primary hover:text-accent transition-colors"
                >
                  View Project <span className="ml-1">→</span>
                </a>
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* View All Projects Button */}
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Button asChild size="lg">
            <a href="#">View All Projects</a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;
