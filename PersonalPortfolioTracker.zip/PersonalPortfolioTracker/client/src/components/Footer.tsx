const Footer = () => {
  return (
    <footer className="bg-background/90 border-t border-primary/30 py-8 px-4">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <a href="#" className="text-xl font-space font-bold text-primary">VAISAKH SRIRAM</a>
            <p className="text-foreground/60 text-sm mt-1">Full-Stack Engineer & Creative Developer</p>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-foreground/60 text-sm">&copy; {new Date().getFullYear()} Vaisakh Sriram. All rights reserved.</p>
            <p className="text-foreground/60 text-xs mt-1">Designed & Built with ❤️ and code</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
