import { motion } from 'framer-motion';
import SkillsVisualization from '@/lib/3d/SkillsVisualization';
import { skillCategories } from '@/lib/constants';

const Skills = () => {
  return (
    <section id="skills" className="py-24 px-4 bg-background/80 relative overflow-hidden">
      <div className="container mx-auto">
        <motion.h2 
          className="text-3xl md:text-4xl font-space font-bold mb-4 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
        >
          <span className="text-gradient">Skill </span>
          <span className="text-foreground">Matrix</span>
        </motion.h2>
        
        <motion.p 
          className="text-center text-foreground/80 max-w-2xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          Interactive visualization of my technical competencies and how they connect.
        </motion.p>
        
        {/* 3D Skills Visualization */}
        <motion.div 
          className="relative mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 1 }}
        >
          <SkillsVisualization className="w-full h-96 mb-12 rounded-xl border border-primary/20" />
        </motion.div>
        
        {/* Skill categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {skillCategories.map((category, index) => (
            <motion.div 
              key={index}
              className="bg-background p-6 rounded-lg border border-primary/30"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
            >
              <h3 className="text-xl font-space font-medium text-primary mb-4">{category.name}</h3>
              <ul className="space-y-2">
                {category.skills.map((skill, skillIndex) => (
                  <li key={skillIndex} className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-primary mr-2"></div>
                    <span className="text-foreground">{skill}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
