import { useEffect, useState, useRef } from 'react';
import Terminal from './Terminal';
import { motion } from 'framer-motion';

const roles = ["Full-Stack Engineer", "Creative Developer", "UI Architect"];

const Hero = () => {
  const [currentRoleIndex, setCurrentRoleIndex] = useState(0);
  const [fade, setFade] = useState(true);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  
  useEffect(() => {
    intervalRef.current = setInterval(() => {
      // Start fade out
      setFade(false);
      
      // Change text after fade out
      setTimeout(() => {
        setCurrentRoleIndex((prev) => (prev + 1) % roles.length);
        // Start fade in
        setFade(true);
      }, 500);
    }, 3000);
    
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  return (
    <section id="hero" className="min-h-screen grid-bg flex flex-col justify-center items-center pt-20 pb-16 px-4 relative overflow-hidden">
      {/* Background particles - To be replaced with Three.js particles in a production environment */}
      <div className="absolute inset-0 pointer-events-none opacity-40"></div>
      
      <div className="container mx-auto flex flex-col items-center text-center z-10">
        {/* Glitching name animation */}
        <motion.h1 
          className="text-4xl md:text-6xl lg:text-7xl font-space font-bold mb-3 relative overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <span className="relative inline-block animate-glitch text-foreground">VAISAKH </span>
          <span className="relative inline-block animate-glitch text-primary">SRIRAM</span>
        </motion.h1>
        
        {/* Role chameleon */}
        <motion.div 
          className="h-8 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
        >
          <div 
            className="text-xl font-space text-accent"
            style={{
              opacity: fade ? 1 : 0,
              transition: 'opacity 0.5s ease'
            }}
          >
            {roles[currentRoleIndex]}
          </div>
        </motion.div>
        
        {/* Terminal component */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <Terminal />
        </motion.div>
        
        {/* Scroll indicator */}
        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.8 }}
        >
          <motion.svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-8 w-8 text-primary" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </motion.svg>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
