import { useEffect, useState, useRef } from 'react';

type Command = {
  cmd: string;
  output: string;
};

const commands: Command[] = [
  { 
    cmd: "whoami", 
    output: "vaisakh-sriram: full-stack engineer with a passion for creative coding and immersive web experiences." 
  },
  { 
    cmd: "ls -la projects/", 
    output: "total 42\ndrwxr-xr-x  neural-interface\ndrwxr-xr-x  data-terrain-explorer\ndrwxr-xr-x  code-sync-platform\ndrwxr-xr-x  webgl-shaders-collection" 
  },
  { 
    cmd: "cat skills.json", 
    output: '{\n  "frontend": ["React", "Vue", "Three.js", "WebGL"],\n  "backend": ["Node.js", "Python", "GraphQL"],\n  "devops": ["AWS", "Docker", "Kubernetes"],\n  "creative": ["Shaders", "Creative Coding", "UI Design"]\n}' 
  }
];

const Terminal = () => {
  const [typedCommand, setTypedCommand] = useState('');
  const [commandOutput, setCommandOutput] = useState('');
  const [currentCommandIndex, setCurrentCommandIndex] = useState(0);
  const [isTyping, setIsTyping] = useState(true);
  const [showCursor, setShowCursor] = useState(true);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setShowCursor((prev) => !prev);
    }, 500);

    return () => {
      clearInterval(cursorInterval);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  useEffect(() => {
    const typeCommand = () => {
      const currentCommand = commands[currentCommandIndex].cmd;
      
      if (isTyping && typedCommand.length < currentCommand.length) {
        setTypedCommand(prev => prev + currentCommand.charAt(prev.length));
        timeoutRef.current = setTimeout(typeCommand, 100);
      } else if (isTyping) {
        setIsTyping(false);
        timeoutRef.current = setTimeout(() => {
          // Show command output
          setCommandOutput(commands[currentCommandIndex].output);
          
          // Prepare for next command
          timeoutRef.current = setTimeout(() => {
            const nextCommandIndex = (currentCommandIndex + 1) % commands.length;
            setCurrentCommandIndex(nextCommandIndex);
            setTypedCommand('');
            setCommandOutput('');
            setIsTyping(true);
            typeCommand();
          }, 3000);
        }, 500);
      }
    };

    typeCommand();

    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [currentCommandIndex, isTyping, typedCommand.length]);

  return (
    <div className="terminal w-full max-w-2xl mx-auto mt-8">
      <div className="terminal-header">
        <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
        <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
        <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
        <div className="ml-2 text-sm text-foreground">terminal@nexushorizon</div>
      </div>
      <div className="terminal-body p-4 font-mono text-sm md:text-base">
        <div className="mb-2 text-foreground">
          <span className="text-primary">visitor@nexus-horizon</span>:
          <span className="text-blue-400">~</span>$ {typedCommand}
          {showCursor && <span className="cursor"></span>}
        </div>
        <div className="text-foreground whitespace-pre-line">
          {commandOutput}
        </div>
      </div>
    </div>
  );
};

export default Terminal;
