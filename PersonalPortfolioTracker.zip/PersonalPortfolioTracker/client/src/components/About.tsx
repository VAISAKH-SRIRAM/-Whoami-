import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { techStack } from '@/lib/constants';
import Avatar from '@/lib/3d/Avatar';

const About = () => {
  return (
    <section id="about" className="py-24 px-4 bg-background/80 relative overflow-hidden">
      <div className="container mx-auto">
        <motion.h2 
          className="text-3xl md:text-4xl font-space font-bold mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
        >
          <span className="text-gradient">About</span>
          <span className="text-foreground"> Me</span>
        </motion.h2>
        
        <div className="flex flex-col lg:flex-row gap-12 items-center">
          {/* 3D Avatar */}
          <motion.div 
            className="w-full lg:w-2/5 flex justify-center"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.5 }}
          >
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full animate-float">
              <div className="absolute inset-0 rounded-full bg-background border-2 border-primary shadow-lg shadow-primary/20 overflow-hidden">
                <Avatar className="w-full h-full" />
              </div>
              {/* Orbiting elements */}
              <div className="absolute w-full h-full animate-spin" style={{ animationDuration: '15s' }}>
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-4 w-4 h-4 bg-primary rounded-full animate-pulse-glow"></div>
              </div>
              <div className="absolute w-full h-full animate-spin" style={{ animationDuration: '20s', animationDirection: 'reverse' }}>
                <div className="absolute top-1/2 left-0 transform -translate-y-1/2 -translate-x-4 w-3 h-3 bg-accent rounded-full animate-pulse-glow"></div>
              </div>
            </div>
          </motion.div>
          
          {/* About Text */}
          <motion.div 
            className="w-full lg:w-3/5"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h3 className="text-xl md:text-2xl font-space font-medium mb-6 text-primary">
              Full-Stack Engineer & Creative Developer
            </h3>
            
            <p className="text-foreground/90 mb-6 leading-relaxed">
              I'm a developer who bridges the gap between functional code and creative expression. With expertise spanning both frontend and backend technologies, I build digital experiences that are both visually compelling and technically robust.
            </p>
            
            <p className="text-foreground/90 mb-8 leading-relaxed">
              My approach combines technical precision with innovative design thinking, allowing me to craft solutions that not only solve problems but create memorable interactions. I'm particularly passionate about creating immersive web experiences that push the boundaries of what's possible in the browser.
            </p>
            
            {/* Tech Stack Pills */}
            <div className="flex flex-wrap gap-2 mb-8">
              {techStack.map((tech, index) => (
                <motion.span 
                  key={index}
                  className="px-3 py-1 bg-background border border-primary/40 rounded-full text-sm text-primary"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: 0.1 * index }}
                >
                  {tech}
                </motion.span>
              ))}
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <Button asChild size="lg">
                <a href="#projects">View Projects</a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="#contact">Get in Touch</a>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
