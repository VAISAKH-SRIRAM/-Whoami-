import { motion } from 'framer-motion';
import { Button } from './ui/button';

const Collaborate = () => {
  return (
    <section id="collaborate" className="py-24 px-4 bg-background relative">
      <div className="container mx-auto">
        <motion.h2 
          className="text-3xl md:text-4xl font-space font-bold mb-4 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
        >
          <span className="text-foreground">Collaboration </span>
          <span className="text-gradient">Zone</span>
        </motion.h2>
        
        <motion.p 
          className="text-center text-foreground/80 max-w-2xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          Explore potential collaborations and how we can work together on innovative projects.
        </motion.p>
        
        {/* Collaborative Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Live Code Editor */}
          <motion.div 
            className="bg-background/60 rounded-lg border border-primary/30 p-6 hover:border-primary/60 transition-all duration-300"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-primary text-2xl mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
              </svg>
            </div>
            <h3 className="text-xl font-space font-medium text-accent mb-2">Code Collaboration</h3>
            <p className="text-foreground/80 mb-4">
              Real-time pair programming and code reviews to solve complex challenges together. I bring expertise in both frontend and backend technologies.
            </p>
            <div className="mt-4 p-4 bg-background rounded border border-primary/20 font-mono text-sm overflow-hidden">
              <div className="flex items-center text-gray-400 mb-2">
                <span className="text-primary">// Example of my collaborative approach</span>
              </div>
              <div><span className="text-blue-400">function</span> <span className="text-accent">optimizeRenderingPipeline</span>() {'{'}</div>
              <div>  <span className="text-blue-400">const</span> strategies = <span className="text-orange-400">['Memoization', 'Virtualization', 'Chunking']</span>;</div>
              <div>  <span className="text-green-400">// Let's discuss which strategy works best for your use case</span></div>
              <div>  <span className="text-blue-400">return</span> strategies.<span className="text-accent">map</span>(strategy =&gt; <span className="text-accent">implement</span>(strategy));</div>
              <div>{'}'}</div>
            </div>
          </motion.div>
          
          {/* Creative Problem Solving */}
          <motion.div 
            className="bg-background/60 rounded-lg border border-primary/30 p-6 hover:border-primary/60 transition-all duration-300"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="text-primary text-2xl mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
            <h3 className="text-xl font-space font-medium text-accent mb-2">Creative Problem Solving</h3>
            <p className="text-foreground/80 mb-4">
              Combining technical expertise with creative thinking to develop innovative solutions for complex problems and unique user experiences.
            </p>
            <div className="mt-4 relative h-40 bg-background rounded border border-primary/20 overflow-hidden">
              {/* Creative visualization */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-40 h-40">
                  <div className="absolute inset-0 border-2 border-primary/30 rounded-full"></div>
                  <motion.div 
                    className="absolute inset-0 border-2 border-primary/20 rounded-full"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 3, repeat: Infinity }}
                  ></motion.div>
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                    <div className="text-primary text-sm mb-1">Brainstorm</div>
                    <div className="text-accent text-xl font-space">Ideas</div>
                    <div className="text-primary text-sm mt-1">Prototype</div>
                  </div>
                  {/* Connecting lines */}
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-px h-16 bg-gradient-to-b from-transparent via-primary to-transparent"></div>
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-px h-16 bg-gradient-to-b from-transparent via-primary to-transparent"></div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
        
        {/* Collaboration Call to Action */}
        <motion.div 
          className="text-center bg-background/50 p-8 rounded-xl border border-primary/30 max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h3 className="text-2xl font-space font-bold text-accent mb-4">Have a project in mind?</h3>
          <p className="text-foreground/80 mb-6 max-w-2xl mx-auto">
            I'm always open to discussing new projects, creative ideas or opportunities to be part of your visions.
          </p>
          <Button asChild size="lg">
            <a href="#contact">Start a Conversation</a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Collaborate;
